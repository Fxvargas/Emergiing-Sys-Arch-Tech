/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */

// Received assistance from online tutor Yusuf Hancar

#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"

#include <ti/drivers/Timer.h>

#include <ti/drivers/apps/LED.h>
#include <ti/drivers/apps/Button.h>

#include <ti/display/Display.h>
#include <ti/drivers/utils/RingBuf.h>


#define BLINKCOUNT            3
#define FASTBLINK             500
#define SLOWBLINK             1000
#define FIFTYMS               50000
#define EVENTBUFSIZE          10


#ifndef CONFIG_BUTTONCOUNT
#define CONFIG_BUTTONCOUNT     2
#endif

#ifndef CONFIG_LEDCOUNT
#define CONFIG_LEDCOUNT        2
#else
#define CONFIG_LED2            2
#endif

typedef struct buttonStats
{
    unsigned int pressed;
    unsigned int clicked;
    unsigned int released;
    unsigned int longPress;
    unsigned int longClicked;
    unsigned int doubleclicked;
    unsigned int lastpressedduration;
} buttonStats;

static volatile uint16_t SysTickCounter  = 0;

static void InitSysTick(void);
static void HandleTimeBase(void);
void ButtonEventstatus(void);
void handleButtonCallback(Button_Handle handle, Button_EventMask events);
void ledBlinkedbyButton(void);

void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
}



void initTimer(void) {

    Timer_Handle timer0;
    Timer_Params params;

    Timer_init();
    Timer_Params_init(&params);
    params.period = 5000000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {}
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {

        /* Failed to start timer */
        while (1) {}

    }

}

Button_Handle    buttonHandle[CONFIG_BUTTONCOUNT];
LED_Handle       ledHandle[CONFIG_LEDCOUNT];
Display_Handle   display;
buttonStats      bStats;
RingBuf_Object   ringObj;
uint8_t          eventBuf[EVENTBUFSIZE];

typedef enum _LedStatus{
    BOTH_LED = 0,
    RED_LED,
    GREEN_LED,

}LedStatus_t;

typedef struct _LED {

    LedStatus_t LedStatus;

}LED_t;

LED_t LED;

#define SYSTICK_TIKCTIME        1000
#define SYSTICKTAG_500_MS       500
#define SYSTICKTAG_1S           1000
#define SYSTICKTAG_1500_MS      500 * 3
#define SYSTICKTAG_3500_MS      500 * 7

typedef struct _SysTickBits {
    uint8_t Tag_500ms           :1;
    uint8_t Tag_1s              :1;
    uint8_t Tag_1500ms          :1;
    uint8_t Tag_3500ms          :1;
    uint8_t rsv                 :4;
} SysTickBits_t;

typedef union _SysTickFlag {
    SysTickBits_t    Bits;
    uint8_t          All;
} SysTickFlag_t;

SysTickFlag_t SysTickFlag;

uint32_t SystemCoreClock = 72000000;

void InitSysTick(void)
{
    SysTick_Config(SystemCoreClock / SYSTICK_TIKCTIME);
}

static void SysTick_Handler(void)
{
    HandleTimeBase();
}

static void HandleTimeBase(void)
{
    SysTickCounter++;

    if (!(SysTickCounter % SYSTICKTAG_500_MS)) {
        SysTickFlag.Bits.Tag_500ms = 1;
    }

    if (!(SysTickCounter % SYSTICKTAG_1S)) {
        SysTickFlag.Bits.Tag_1s = 1;
    }

    if (!(SysTickCounter % SYSTICKTAG_1500_MS)) {
        SysTickFlag.Bits.Tag_1500ms = 1;
    }

    if (!(SysTickCounter % SYSTICKTAG_3500_MS)) {
        SysTickFlag.Bits.Tag_3500ms = 1;
    }

}


/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{
    /* Toggle an LED */
    GPIO_toggle(CONFIG_GPIO_LED_0);
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{
    /* Toggle an LED */
    GPIO_toggle(CONFIG_GPIO_LED_1);
}

void ButtonEventstatus(void)
{
    uint8_t event;

    while(RingBuf_get(&ringObj, &event) >= 0)
    {
        if(event & Button_EV_CLICKED)
        {
            Display_print0(display, 0, 0, "Button:Click");
        }
        if(event & Button_EV_DOUBLECLICKED)
        {
            Display_print0(display, 0, 0, "Button:Double Click");
        }
        if(event & Button_EV_LONGPRESSED)
        {
            Display_print0(display, 0, 0, "Button:Long Pressed");
        }
    }
}

void handleButtonCallback(Button_Handle handle, Button_EventMask events)
{
    uint_least8_t ledIndex = (buttonHandle[CONFIG_GPIO_BUTTON_0] == handle) ?
            CONFIG_GPIO_LED_0 : CONFIG_GPIO_LED_1;
    LED_Handle led = ledHandle[ledIndex];

    if(Button_EV_PRESSED == (events & Button_EV_PRESSED))
    {
        bStats.pressed++;
    }

    if(Button_EV_RELEASED == (events & Button_EV_RELEASED))
    {
        bStats.released++;
    }

    if(Button_EV_CLICKED == (events & Button_EV_CLICKED))
    {
        bStats.clicked++;
        bStats.lastpressedduration =
                Button_getLastPressedDuration(handle);

        /* Put event in ring buffer for printing */
        RingBuf_put(&ringObj, events);

        if(LED_STATE_BLINKING == LED_getState(led))
        {
            LED_stopBlinking(led);
            LED_setOff(led);
        }
        else
        {
            LED_toggle(led);
        }
    }

    if(Button_EV_LONGPRESSED == (events & Button_EV_LONGPRESSED))
    {
        bStats.longPress++;

        /* Put event in ring buffer for printing */
        RingBuf_put(&ringObj, events);

        LED_startBlinking(led, SLOWBLINK, LED_BLINK_FOREVER);
    }

    if(Button_EV_LONGCLICKED == (events & Button_EV_LONGCLICKED))
    {
        bStats.longClicked++;
        bStats.lastpressedduration = Button_getLastPressedDuration(handle);
        LED_stopBlinking(led);
    }

    if(Button_EV_DOUBLECLICKED == (events & Button_EV_DOUBLECLICKED))
    {
        bStats.doubleclicked++;

        /* Put event in ring buffer for printing */
        RingBuf_put(&ringObj, events);

        if(LED_STATE_BLINKING != LED_getState(led))
        {
            LED_startBlinking(led, FASTBLINK, BLINKCOUNT);
        }
        else
        {
            LED_stopBlinking(led);
            LED_setOff(led);
        }
    }
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{

    int inc;
    bool dir = true;

    Button_Params  buttonParams;
    LED_Params     ledParams;

    /* Call driver init functions */
    InitSysTick();
    Button_init();
    LED_init();
    GPIO_init();

    Button_Params_init(&buttonParams);
    buttonHandle[CONFIG_GPIO_BUTTON_0] = Button_open(CONFIG_GPIO_BUTTON_0,
                                              handleButtonCallback,
                                              &buttonParams);

    buttonHandle[CONFIG_GPIO_BUTTON_1] = Button_open(CONFIG_GPIO_BUTTON_1,
                                              handleButtonCallback,
                                              &buttonParams);

    LED_Params_init(&ledParams);
    ledHandle[CONFIG_GPIO_LED_0] = LED_open(CONFIG_GPIO_LED_0, &ledParams);
    ledHandle[CONFIG_GPIO_LED_1] = LED_open(CONFIG_GPIO_LED_1, &ledParams);

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    while(1)
    {

        ButtonEventstatus();

        if (SysTickFlag.Bits.Tag_500ms) {
            SysTickFlag.Bits.Tag_500ms = 0;

            ledBlinkedbyButton();
        }

    }

    return (NULL);
}

void ledBlinkedbyButton(void)
{
        switch (LED.LedStatus)
        {

            case  BOTH_LED:

                if (SysTickFlag.Bits.Tag_3500ms) {

                    SysTickFlag.Bits.Tag_3500ms = 0;
                    gpioButtonFxn0(1);
                    gpioButtonFxn1(1);
                    printf ("SOS every 3500ms blinking...");
                }

                if (bStats.clicked == 1) {
                    LED.LedStatus = RED_LED | GREEN_LED;
                }

            break;

            case  RED_LED:

                if (SysTickFlag.Bits.Tag_3500ms) {

                    SysTickFlag.Bits.Tag_1500ms = 0;
                    gpioButtonFxn1(0);
                }

            break;

            case  GREEN_LED:

                if (SysTickFlag.Bits.Tag_500ms) {

                    SysTickFlag.Bits.Tag_500ms = 0;
                    gpioButtonFxn0(0);
                }

            break;


        }
}
